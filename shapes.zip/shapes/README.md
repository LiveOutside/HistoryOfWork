1. Создайте в директории src классы Circle, Square, Triangle, Point по следующей диаграмме  

![](assets/diagram.png)

методы toString() должны возвращать строку виду "ClassName {fieldName: value, fieldName2: value}" (пример реализации можно посмотреть в классе Shape)

2. В классе Shape реализуйте статический метод findMaxAreaShape()  
(сигнатура описана в диаграмме)

3. Запустите программу из Main. Какую фигуру с максимальной площадью вывела программа?