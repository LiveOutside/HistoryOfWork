public class Square extends Shape {
    private Point corner;
    private double size;

    public Square(Point corner, double size, String color) {
        super(color);
        this.size=size;
        this.corner=corner;
    }

    @Override
    public double getArea() {
        return super.getArea();
    }
    @Override
    public String toString() {
        return String.format("Square {corner: %s, size: %f, color: %s}", corner, size, getColor());
    }
}
