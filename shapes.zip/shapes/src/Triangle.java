public class Triangle extends  Shape {

    private Point a;
    private Point b;
    private Point c;

    public Triangle(Point a,Point b,Point c,String color){
        super(color);
        this.a=a;
        this.b=b;
        this.c=c;
    }

    @Override
    public double getArea() {
        return super.getArea();
    }
    @Override
    public String toString() {
        return String.format("Triangle {Point: %s, Point: %s, Point: %s, color: %s,}", a,b,c, getColor());
    }
}
