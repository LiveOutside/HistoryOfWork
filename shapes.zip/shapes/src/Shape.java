public class Shape {
    private String color;

    public Shape(String color) {
        this.color = color;
    }

    public static Shape findMaxAreaShape(Shape[] shapes) {
        Shape maxArea = shapes[0];
        for (Shape s:shapes) {
            if(s.getArea()>maxArea.getArea()){
                maxArea=s;
            }
        }
        return maxArea;
    }


    public String getColor() {
        return color;
    }

    public double getArea() {
        return Double.NaN;
    }

    @Override
    public String toString() {
        return String.format("Shape {color: %s}", color);
    }
}

