public class Point {
    private double x;
    private double y;

    public Point(double x, double y){
    }

    public double getX() {
        return x;
    }
    public double getY(){
        return  y;
    }
    @Override
    public String toString() {
        return String.format("Point {x: %f, y: %f}", x, y);
    }

}
