package com.example.myapplication;

public class Roomer {

    public String getDescription (String room) {
        switch (room.toLowerCase()) {
            case "living room":
                return "Place where you can meet with ur friends =) ";
            case "bathroom":
                return "You can wash your body here. ";
            case "kitchen":
                return "Give me some foooooooooood. ";
            default:
                return "cluchilac baga no vse je ficha";
        }
    }
}