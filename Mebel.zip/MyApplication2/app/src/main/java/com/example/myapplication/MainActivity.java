package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
//import android.util.Log;
import android.view.View;
//import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
private Roomer roomer = new Roomer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickButton(View view) {
        Spinner room = (Spinner)findViewById(R.id.spinner_room);
        TextView texter = (TextView)findViewById(R.id.textView);

        String selected = String.valueOf(room.getSelectedItem());
        texter.setText(roomer.getDescription(selected));
    }

}


